package test;

import dao.impl.MedicamentoDaoH2;
import model.Medicamento;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import service.MedicamentoService;

class MedicamentoServiceTest {

    private MedicamentoService medicamentoService = new MedicamentoService(new MedicamentoDaoH2());

    @Test
    public void guardarMedicamento() {
        Medicamento medicamento = new Medicamento("Ibuprofeno", "lab123", 1000, 200.0);
        medicamentoService.guardar(medicamento);
        Assert.assertTrue(medicamentoService.buscar(1) != null);
    }

    @Test
    public void traerPorId() {
        Medicamento medicamento = medicamentoService.buscar(1);
        Assert.assertTrue(medicamento != null);
    }
}