package service;

import dao.IDao;
import model.Medicamento;

public class MedicamentoService {

    private IDao<Medicamento> medicamentoDao;

    public MedicamentoService(IDao<Medicamento> medicamentoDao) {
        this.medicamentoDao = medicamentoDao;
    }

    public Medicamento guardar(Medicamento medicamento) {
        return medicamentoDao.guardar(medicamento);
    }

    public Medicamento buscar(Integer id) {
        return medicamentoDao.buscar(id);
    }
}
