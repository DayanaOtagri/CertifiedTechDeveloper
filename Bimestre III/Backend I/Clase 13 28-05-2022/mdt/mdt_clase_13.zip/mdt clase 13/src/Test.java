import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;


public class Test {

    public static Connection getConnection() throws Exception {
        Class.forName("org.h2.Driver").newInstance();
        return DriverManager.getConnection("jdbc:h2:~/test", "sa", "") ;

    }
    private static final String SQL_CREATE_TABLE = "DROP TABLE IF EXISTS ODONTOLOGO; CREATE TABLE ODONTOLOGO "
            + "("
            + " ID INT PRIMARY KEY,"
            + " NOMBRE varchar(100) NOT NULL, "
            + " APELLIDO varchar(100) NOT NULL,"
            + " MATRICULA varchar(100) NOT NULL"
            + " )";

    private static final String SQL_INSERT =  "INSERT INTO ODONTOLOGO (ID, NOMBRE, APELLIDO, MATRICULA) VALUES (?,?,?,?)";
    private static final String SQL_UPDATE =  "UPDATE ODONTOLOGO SET MATRICULA=? WHERE ID=?";

    public static void main(String[] args) throws Exception{
        Odontologo odontologo = new Odontologo("Perry", "perez","abc123");

        Connection con = null;

        try {
            con= getConnection();
            con.setAutoCommit(false);
            Statement statement = con.createStatement();
            statement.execute(SQL_CREATE_TABLE);

            PreparedStatement psInsert = con.prepareStatement(SQL_INSERT);
            psInsert.setInt(1, 1);
            psInsert.setString(2, odontologo.getNombre());
            psInsert.setString(3, odontologo.getApellido());
            psInsert.setString(4, odontologo.getMatricula());

            psInsert.execute();

            PreparedStatement psUpdate1 = con.prepareStatement(SQL_UPDATE);
            psUpdate1.setString(1, "cdf123");
            psUpdate1.setInt(2, 1);
            psUpdate1.executeUpdate();

            con.commit();
            con.setAutoCommit(true);

        }catch (Exception e){
            con.rollback();
        }finally {
            con.close();
        }

        Connection connection2= getConnection();
        String sql = "SELECT * FROM ODONTOLOGO";
        Statement sqlSmt = connection2.createStatement();
        ResultSet rs = sqlSmt.executeQuery(sql);
        while (rs.next()) {
            System.out.println(rs.getInt(1) + rs.getString(2) + rs.getString(3) + rs.getString(4));
        }
    }

}
