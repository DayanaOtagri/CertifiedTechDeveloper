package com.dh.clinica.dao;

public interface IDao <T> {
    public T guardar(T t);
    public  T buscar(Integer id);
    public void eliminar(Integer id);
    public T modificar(Integer id);
}
