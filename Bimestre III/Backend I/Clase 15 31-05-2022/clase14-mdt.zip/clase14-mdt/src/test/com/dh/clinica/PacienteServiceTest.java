package test.com.dh.clinica;


import com.dh.clinica.dao.impl.PacienteDaoH2;
import com.dh.clinica.model.Paciente;
import com.dh.clinica.service.PacienteService;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.sql.Date;
import java.time.LocalDate;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PacienteServiceTest {

    private PacienteService pacienteService = new PacienteService(new PacienteDaoH2());

    @Test
    public  void guardarPaciente(){
        Paciente paciente = new Paciente("Jimenez", "Rocio", 12345, LocalDate.of(2022,5,31));
        pacienteService.guardar(paciente);
//        Assert.assertTrue(pacienteService.buscar(1) != null);

    }

}
