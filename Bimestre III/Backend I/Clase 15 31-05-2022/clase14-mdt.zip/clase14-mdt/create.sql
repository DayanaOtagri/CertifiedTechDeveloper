create table if not exists pacientes (id int auto_increment primary key,apellido varchar(255),nombre varchar (255),dni int,fechaIngreso date);
create table if not exists domicilio (id int auto_increment primary key,calle varchar(255),numero varchar (255),localidad varchar (255) ,provincia varchar (255));
