package dh.vendedores.main.model;

public class Afiliado extends Vendedor{

    public Afiliado( String nombre) {
        super(nombre);
    }


}
