import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Test {

    //método conection se conecta al driver
    public static Connection getConnection() throws Exception {
        Class.forName("org.h2.Driver").newInstance();
        return DriverManager.getConnection("jdbc:h2:~/test", "sa", "");

    }

    private static final String SQL_CREATE_TABLE = "DROP TABLE IF EXISTS FIGURAS; CREATE TABLE FIGURAS "
            + "("
            + " ID INT PRIMARY KEY,"
            + " FIGURA varchar(100) NOT NULL, "
            + " COLOR varchar(100) NOT NULL "
            + " )";

    private static final String SQL_INSERT1 =  "INSERT INTO FIGURAS (ID, FIGURA, COLOR) VALUES (1,'Circulo','rojo')";
    private static final String SQL_INSERT2 =  "INSERT INTO FIGURAS (ID, FIGURA, COLOR) VALUES (2,'Circulo','amarillo')";
    private static final String SQL_INSERT3 =  "INSERT INTO FIGURAS (ID, FIGURA, COLOR) VALUES (3,'Cuadrado','verde')";
    private static final String SQL_INSERT4 =  "INSERT INTO FIGURAS (ID, FIGURA, COLOR) VALUES (4,'Cuadrado','celeste')";
    private static final String SQL_INSERT5 =  "INSERT INTO FIGURAS (ID, FIGURA, COLOR) VALUES (5,'Cuadrado','gris')";



    //Creamos un objeto de tio connection dentro del main
    public static void main(String[] args) throws Exception{
        Connection connection=null;
        //Cración de la conexion con la bd
        try{
            connection = getConnection();
            //creamos un objetos statement, esto para poder ejecutar consultas, en este caso creamos una tabla
            Statement statement = connection.createStatement();
            statement.execute(SQL_CREATE_TABLE);

            Statement statement1 = connection.createStatement();
            statement1.execute(SQL_INSERT1);

            Statement statement2 = connection.createStatement();
            statement2.execute(SQL_INSERT2);

            Statement statement3 = connection.createStatement();
            statement3.execute(SQL_INSERT3);

            Statement statement4 = connection.createStatement();
            statement4.execute(SQL_INSERT4);

            Statement statement5 = connection.createStatement();
            statement5.execute(SQL_INSERT5);

            //Config para hacer consltas (similar a base de datos)
            String sql = "SELECT * FROM FIGURAS";
            Statement sqlSmt = connection.createStatement();
            ResultSet rs = sqlSmt.executeQuery(sql); //sería la respuesta como un tipo d elista objeto
            //mostramos los valores por pantalla
            while (rs.next()) {
                System.out.println(rs.getInt(1)+rs.getString(2)+rs.getString(3));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            connection.close();
        }

    }

}
