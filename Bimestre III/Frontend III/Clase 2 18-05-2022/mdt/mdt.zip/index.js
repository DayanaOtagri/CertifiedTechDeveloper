const products = [
    { id: 1, name: "Manzana", isStock: true },
    { id: 2, name: "Pera", isStock: true },
    { id: 3, name: "Naranja", isStock: true },
    { id: 4, name: "Banana", isStock: true },
    { id: 5, name: "Kiwi", isStock: true },
    { id: 6, name: "Durazno", isStock: false },
    { id: 7, name: "Cereza", isStock: false },
    { id: 8, name: "Anana", isStock: false }
];

const displayProducts = argument => {
    if (argument === 1) {
        return (
            <ul>
                {products.map(product => {
                    if (product.isStock) {
                        <li key={product.id}>{product.name}</li>
                    }
                })}
            </ul>
        )
    }
    else if (argument === 2) {
        return (
            <ul>
                {products.map(product => {
                    if (!product.isStock) {
                        <li key={product.id}>{product.name}</li>
                    }
                })}
            </ul>
        )
    }
};

const App = (
    <div>
        {
            displayProducts(1)
        }
        {
            displayProducts(2)
        }
    </div>
);

console.log(displayProducts)

const hookedElement = document.getElementById("root");
ReactDOM.render(App, hookedElement)