import org.apache.log4j.Logger;

import java.io.File;
import java.util.List;
import java.util.ArrayList;

import org.apache.log4j.PropertyConfigurator;

public class Main {

    private final static Logger logger = Logger.getLogger(Main.class);

    public static void main(String[] args) {

        File log4jfile = new File("./src/config/log4j.properties");
        PropertyConfigurator.configure(log4jfile.getAbsolutePath());

        Persona p1 = new Persona("Pepito", "Perez", 20);
        Persona p2 = new Persona("Peppa", "Pig", 10);
        Persona p3 = new Persona("John", "Smith", 30);
        Persona p4 = new Persona("Dante", "Diaz", 25);
        Persona p5 = new Persona("Pocholo", "Muñoz", 43);

        List<Persona> people = new ArrayList<>();
        people.add(p1);
        people.add(p2);
        people.add(p3);
        people.add(p4);
        people.add(p5);
        ListaPersona listaPersona = new ListaPersona(people);
    }
}