import org.apache.log4j.Logger;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class ListaPersona {

    private static final Logger logger = Logger.getLogger(ListaPersona.class);
    private List<Persona> personas = new ArrayList<>();

    public ListaPersona(List<Persona> personas) {
        this.personas = personas;
        promedioEdad();
        maximayMinimaEdad();
    }

    public Integer promedioEdad() {
        Integer suma = 0;
        for (Persona persona : personas) {
            suma += persona.getEdad();
        }
        Integer promedio = suma / personas.size();
        logger.info("El promedio de edades es: " + promedio);
        return promedio;
    }

    public void maximayMinimaEdad() {
        List<Integer> arrlist = new ArrayList<Integer>();
        for (Persona persona : personas) {
            arrlist.add(persona.getEdad());
        }
        Integer[] edades = new Integer[personas.size()];
        edades = arrlist.toArray(edades);
        Integer max = Collections.max(Arrays.asList(edades));
        Integer min = Collections.min(Arrays.asList(edades));
        logger.info("La persona con mas edad tiene : " + max);
        logger.info("La persona con menos edad tiene : " + min);
    }
}
