import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Empresa empresa = new Empresa("La empresa", "1234");
        Empleado empleado = new Empleado("Juan", "Perez", "1234");
        Empleado empleado1 = new Empleado("Juana", "Perez", "456");
        Empleado empleado2 = new Empleado("Cecilia", "Abate", "789");
        Empleado empleado3 = new Empleado("Ana", "Perez", "369");
        empresa.agregarEmpleado(empleado);
        empresa.agregarEmpleado(empleado1);
        empresa.agregarEmpleado(empleado2);
        empresa.agregarEmpleado(empleado3);

        FileOutputStream fo;
        try {
            fo= new FileOutputStream("ListadoEmpleados.txt");
            ObjectOutputStream dos = new ObjectOutputStream(fo);
            dos.writeObject(empresa.getEmpleados());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        List<Empleado> listadoEmpleados= null;
        FileInputStream fi = null;

        try {
            fi =new FileInputStream("ListadoEmpleados.txt");
            ObjectInputStream ois = new ObjectInputStream(fi);
            listadoEmpleados = (ArrayList) ois.readObject();
            System.out.println(listadoEmpleados);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {


            String filePath = "C:\\Users\\Maskiti & Frelou\\empleados.txt";
            FileWriter fw = new FileWriter(filePath, true);
            BufferedWriter bw = new BufferedWriter(fw);
            for (Empleado listadoEmpleado : listadoEmpleados) {
                bw.write(listadoEmpleado.toString() + ", " );

            }

            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
