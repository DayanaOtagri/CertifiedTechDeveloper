package com.example.mdt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MdtApplication {

	public static void main(String[] args) {
		SpringApplication.run(MdtApplication.class, args);
	}

}
