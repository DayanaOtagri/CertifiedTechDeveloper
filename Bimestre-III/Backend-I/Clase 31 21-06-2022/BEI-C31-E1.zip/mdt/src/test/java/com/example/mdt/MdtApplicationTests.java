package com.example.mdt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MdtApplicationTests {

	@Test
	void contextLoads() {
	}

}
