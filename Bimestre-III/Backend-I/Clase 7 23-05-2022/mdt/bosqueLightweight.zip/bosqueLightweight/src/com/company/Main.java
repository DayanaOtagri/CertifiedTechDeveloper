package com.company;

import com.company.digitalhouse.lightweight.dto.Arbol;
import com.company.digitalhouse.lightweight.dto.Bosque;
import com.company.digitalhouse.lightweight.factory.ArbolFactory;

public class Main {

    public static void main(String[] args) {
        Arbol ar2 = new Arbol(500, 300, "Frutal", "rojo");
        Arbol ar3 = new Arbol(100, 200, "afafga", "celeste");
        Arbol ar1 = new Arbol(200, 400, "Ornamental", "verde");
        Bosque bosque = new Bosque();


        for (int i = 0; i < (1000000/3); i++) {
            bosque.plantarArbol(ar1);
            bosque.plantarArbol(ar2);
            bosque.plantarArbol(ar3);
        }
        bosque.plantarArbol(ar3);

        System.out.println();

        System.out.println(bosque.tiposDeArboles());
    }
}
