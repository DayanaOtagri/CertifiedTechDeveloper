package com.company.digitalhouse.lightweight.dto;

import com.company.digitalhouse.lightweight.factory.ArbolFactory;

import java.util.ArrayList;
import java.util.List;

public class Bosque {
    private List<Arbol> bosque;
    private ArbolFactory factory;


    public Bosque() {
        this.bosque = new ArrayList<>();
        factory = new ArbolFactory();
    }

    public List<Arbol> getBosque() {
        return bosque;
    }

    public String tiposDeArboles(){
        return factory.tiposDeArbol();
    }

    public void plantarArbol(Arbol arbol){
        factory.getArbol(arbol.getAlto(), arbol.getHorizontal(), arbol.getTipo(), arbol.getColor());
        this.bosque.add(arbol);
        System.out.println("Arbol plantado! Cant. de arboles: " + bosque.size());
    }
}
