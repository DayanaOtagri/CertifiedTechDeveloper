package com.company.digitalhouse.lightweight.factory;

import com.company.digitalhouse.lightweight.dto.Arbol;

import java.util.HashMap;
import java.util.Map;

public class ArbolFactory {
    private static Map<String, Arbol> arbolMap = new HashMap<>();

    public void getArbol(int alto, int horiz, String tipo, String color){
        String key = "alto:" +alto+ "horiz:" +horiz+ "tipo:" +tipo+ "color:" +color;

        if (!arbolMap.containsKey(key)){
            Arbol arbol = new Arbol(alto, horiz, tipo, color);
            System.out.println("CREANDO ARBOL DESDE 0");
            arbolMap.put(key, arbol);
        }else System.out.println("ARBOL EXISTENTE");
        System.out.println(arbolMap.get(key));
    }

    public String tiposDeArbol() {
        return "Cantidad de tipos de arbol: " + arbolMap.size();
    }
}
