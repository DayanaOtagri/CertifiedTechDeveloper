package com.company.digitalhouse.lightweight.dto;

public class Arbol {
    private int alto;
    private int horizontal;
    private String tipo;
    private String color;

    public Arbol(int alto, int horizontal, String tipo, String color) {
        this.alto = alto;
        this.horizontal = horizontal;
        this.tipo = tipo;
        this.color = color;
    }

    public int getAlto() {
        return alto;
    }

    public int getHorizontal() {
        return horizontal;
    }

    public String getTipo() {
        return tipo;
    }

    public String getColor() {
        return color;
    }

    @Override
    public String toString() {
        return "Arbol{" +
                "alto=" + alto +
                ", horizontal=" + horizontal +
                ", tipo='" + tipo + '\'' +
                ", color='" + color + '\'' +
                '}';
    }
}
