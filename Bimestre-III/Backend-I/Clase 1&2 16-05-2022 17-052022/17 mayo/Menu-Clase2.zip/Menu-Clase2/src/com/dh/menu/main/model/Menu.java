package com.dh.menu.main.model;

public class Menu {

    private Double precioBase;
    private Integer cantJuguetesAdiconales;
    private Integer cantidadSalsas;

    public Menu(Double precioBase) {
        this.precioBase = precioBase;
    }

    public Double calcularPrecio(){

    }

    public void armarPaquete(){

    }
}
