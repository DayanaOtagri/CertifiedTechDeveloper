package com.dh.menu.main.service.impl;

import com.dh.menu.main.model.Menu;

public class MenuVegetariano extends Menu {

    private Boolean tieneEspeciasAdicional;



    public MenuVegetariano(Double precioBase, Boolean tieneEspeciasAdicional, Integer cantidadSalsas) {
        super(precioBase);
        this.cantidadSalsas = cantidadSalsas;
        this.tieneEspeciasAdicional = tieneEspeciasAdicional;
    }
}
