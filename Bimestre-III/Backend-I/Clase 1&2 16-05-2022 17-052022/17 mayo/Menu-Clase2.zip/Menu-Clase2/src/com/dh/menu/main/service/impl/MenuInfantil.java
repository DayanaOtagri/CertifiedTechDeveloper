package com.dh.menu.main.service.impl;

import com.dh.menu.main.model.Menu;

public class MenuInfantil extends Menu {




    public MenuInfantil(Double precioBase, Integer cantJuguetesAdiconales) {
        super(precioBase);
        this.cantJuguetesAdiconales = cantJuguetesAdiconales;
    }
}
