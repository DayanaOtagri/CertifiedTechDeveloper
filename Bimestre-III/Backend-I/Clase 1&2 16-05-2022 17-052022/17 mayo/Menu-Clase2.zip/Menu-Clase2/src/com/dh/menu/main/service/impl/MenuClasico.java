package com.dh.menu.main.service.impl;

import com.dh.menu.main.model.Menu;

public class MenuClasico extends Menu {

    public MenuClasico(Double precioBase) {
        super(precioBase);
    }
}
