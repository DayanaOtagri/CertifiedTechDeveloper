import java.io.*;
import java.util.ArrayList;

public class Agenda {
    public static void main(String[] args) {
        Contacto c1 = new Contacto("Fred", "fred24@gmail.com", "301 3423992");
        Contacto c2 = new Contacto("Pol", "pol21@gmail.com", "301 3223997");
        Contacto c3 = new Contacto("Fresia", "fresia2@gmail.com", "303 3423990");
        Contacto c4 = new Contacto("Irina", "Irina4@gmail.com", "302 5423995");
        Contacto c5 = new Contacto("Grecia", "greciaV@gmail.com", "301 342399");
        Contacto c6 = new Contacto("Galia", "galiaa@gmail.com", "303 7423993");
        Contacto c7 = new Contacto("Ofelia", "ofeliag@gmail.com", "304 7423992");
        Contacto c8 = new Contacto("Sebastian", "sebasf@gmail.com", "304 7393456");


        ArrayList<Contacto> amigos = new ArrayList<>();
        ArrayList<Contacto> familia = new ArrayList<>();
        ArrayList<Contacto> trabajo = new ArrayList<>();

        //Amigos
        amigos.add(c1);
        amigos.add(c5);
        amigos.add(c6);
        amigos.add(c7);


        //Familia
        familia.add(c2);
        familia.add(c3);


        //Trabajo
        trabajo.add(c4);
        trabajo.add(c8);


        //Grabamos el array en un archivo
        try {
            FileOutputStream file = new FileOutputStream("OutputFile.txt");
            //Creamos una salida para el objeto
            ObjectOutputStream archivo = new ObjectOutputStream(file);

            //teniendo el archivo de salida, agregamos los datos de contacto
            archivo.writeObject(amigos);
            archivo.writeObject(familia);
            archivo.writeObject(trabajo);

            //Una vez agregado todo, cerramos el proceso
            archivo.close();


            //Ya teniendo guardados los datos, podemos abrir el archivo para leer y listar
            FileInputStream fileIn = new FileInputStream("OutputFile.txt");
            ObjectInputStream archivoIn = new ObjectInputStream(fileIn);

            //Para leer el archivo generamos un array (contrario a serializar)
            ArrayList<Contacto> categoria;

            //Iteramos
            for(int i=0; i<3; i++) {
                System.out.println("Categoría " + (i+1));
                System.out.println("==============================================================================");
                //Casteamos, ya que lo que nos va generar es un objeto y categoría es un array
                categoria = (ArrayList<Contacto>) archivoIn.readObject();

                //Iteramos sobre categoría para listar las categorías de contactos
                for (Contacto contacto : categoria) {
                    System.out.println(contacto);
                }
                System.out.println("\n");
            }
            //Una vez listado los contactos, cerramos el proceso
            archivoIn.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }

}
