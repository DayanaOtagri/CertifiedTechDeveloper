

//ejemplo playground//
let nombre = 'sandra';
let apellido2 = 'parra';
let edad = 15;
let telefono = 3057124803
let sabeProgramar = 'true';
console.log(nombre,apellido2,edad,telefono,sabeProgramar);

//palabra reservada let ** variable que pertenece a un solo bloque de llaves o de ejecucion//

let numero_preferido = 10;

console.log (numero_preferido);

if (true){
    let numero_preferido = 5;
    console.log(numero_preferido);
}


//constante const  jamas cambiara el valor que se le asigne//
const SEXO = 'femenino';
console.log (SEXO);
