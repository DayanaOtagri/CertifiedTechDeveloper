
//informacion almacenada en la misma variable//

let rutina = {
    despertartemprano : true,
    horadespertar : 6,
    desayunarencasa : false,
}

console.log(rutina);

// tipos de datos //

let numero = 15; // numerico//
let nada = null; //nulo//
let texto = "hola"; // string//
let verdadero = true; // booleano//
