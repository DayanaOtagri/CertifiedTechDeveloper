function generaciones(anioNacimiento) {
    if (anioNacimiento <= 1964){
        return "Baby boomer";
    } else if (anioNacimiento >= 1965 && anioNacimiento <= 1981) {
        return "Generacion x";
    } else if (anioNacimiento >= 1982 && anioNacimiento <= 1997) {
        return "Millennial";
    } else if(anioNacimiento > 1997) {
        return "Generacion z";
    }
   
   }

   console.log (generaciones(1981));

   //ultimopunto//

   function mayorMenorQue100( N1, N2 ){

    const suma = N1 + N2;
    if( suma < 100 ){
      return "la suma de " + N1 + " y "  + N2 + " es menor que 100"
    } else if ( suma == 100 ) {
       return "la suma de " + N1 + " y "  + N2 + " es exactamente 100";
    }
    else if ( suma > 100 ){
        return " la suma de " + N1 + " y "  + N2 + " es mayor que 100 "

    }
    
}
console.log(mayorMenorQue100 (80, 60))