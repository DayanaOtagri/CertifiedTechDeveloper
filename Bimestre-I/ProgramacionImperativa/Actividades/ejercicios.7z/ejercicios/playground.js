//Operadores matemáticos//
let numero= 6; 
numero++;
console.log(++numero);

//+ otro numero

numero=numero+5;
console.log(numero);

//forma abreviada, funciona con todos los operadores

numero +=6;
console.log(numero);

// comparacion simple  debo declarar el segundo numero para saber con que va a comparar 

let numero2=8;
 console.log (numero==numero2); // retorna false

 let numero3=19;
 console.log(numero==numero3); // debo tener muy presente el valor actual que tiene la variable con la que voy a comparar

// comparacion estricta
 let numero4="19";
 console.log(numero===numero4); // retorna false  porq lo estoy comparando con string

 console.log(19>=numero);
 //Operadores Logicos && and

 

 //concatenacion

 let nombre ="sandra"
 let apellido = "sanchez"

 console.log(nombre + " " + apellido);

 //operaciones aritmeticas basicas

 //suma

 let primerNumero =6;
 let segundoNumero=8;
 let resultadoSuma =primerNumero+segundoNumero;
 let resultadoResta=primerNumero-segundoNumero;
 let resultadoMultiplicacion =primerNumero*segundoNumero;
 let resultadoDivision =primerNumero/segundoNumero;
    console.log (resultadoSuma );
    console.log (resultadoResta );
    console.log (resultadoMultiplicacion );
    console.log (resultadoDivision );

//funciones 
// expresada

let sumar = function(numeroA,numeroB){
   return numeroA + numeroB;
}

console.log(sumar(100,20));

// funcion Declarar

function Resta(numeroC,numeroD){
   return numeroC- numeroD;
}

console.log(Resta(100,20));

//scope global
let elMejorLenguaje ="Javascript,es lo màs";
function estoyAprendiendo (){
   return elMejorLenguaje; 
}

console.log(estoyAprendiendo());

// scope local. la variable solo puede ser usada dentro de la funcion 


function hola(){
   let saludo = "hola que tal?";
   return saludo;
   
}

console.log (hola ());

//ACLARANDO EL USO DE LA VARIABLE GLOBAL

function pruebascope (){ //creo la funcion
   return elMejorLenguaje; // pido que me devuelva la variable global
}

console.log (pruebascope()); // imprimo en pantalla la ejecucion de la funcion 

// otro ejemplo

function ejemplo1(){
   let saludo = "hola, soy una función";
   return saludo;

}
console.log(ejemplo1());

// es posible asignarle a una variable el valor de funcion

let ejemplo =
function (){
   return "hola, soy una función expresada"; 
}



//
let numero = 5
 
function anterior(numero){
  return numero -1
}
 
function triple(numero){
  return numero*3
}
 
function anteriorDelTriple(numero){
  let resultado
  resultado = triple(numero);
  resultado = anterior(resultado)
  return resultado
}
 
 
 
console.log(anterior(numero))
 
console.log(triple(numero))
 
console.log(anteriorDelTriple(numero))





