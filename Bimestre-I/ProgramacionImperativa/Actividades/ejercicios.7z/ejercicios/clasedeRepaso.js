const numeros = [1,2,3,4,"cosme"];
console.log(numeros[2]);

// ejemplo2

function preparartinto(cafe,agua){
    const tinto = cafe + agua;
    return tinto;
}
console.log(preparartinto ("pone tinto","pone agua"));

// mismo ejemplo con variables

const resultadoTinto = preparartinto("pone tinto","pone agua");

console.log(resultadoTinto+"vacio");