 const alicia = [23, 69, 32];
 const bob = [40, 67, 90];
 
 function encontrarGanador(a, b) {
    //su solución aquí
    let puntajeA = 0;
    let puntajeB = 0;
    for(let i = 0; i < a.length; i++)
    {
        if(a[i] > b[i])
        {
            puntajeA++;
        }
        else if(a[i] < b[i])
        {
            puntajeB++;
        }
    }
    if(puntajeA > puntajeB)
    {
        return "Alicia es el ganador";
    }
    else if(puntajeA < puntajeB){
        return "Bob es el ganador";
    }
    else
    {
        return "Empate";
    }
 }
console.log(encontrarGanador(alicia,bob));

// segundo punto 

function digitalHouse(num1, num2) {
    for(let i=1; i < 101;i++){
        if (i % num1 == 0){
            console.log("Digital");
        }
        else if(i % num2 == 0){
            console.log("House");
        }
        else if(i % num2 == 0 && i % num1 == 0){
            console.log("Digital House");
          
        }else{
            console.log(i);
        }
    }
}

digitalHouse(8,25);

// suamtoria de una array

var numeros = [1, 2, 3, 4, 5], suma = 0;
    forEach (numeros, function(numero){
        suma += numero;
    });
    console.log(suma);
    

