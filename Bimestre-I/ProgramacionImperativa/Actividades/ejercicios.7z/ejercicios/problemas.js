function mayorMenorIgual(N1 ,N2){
 if (N1< N2){
     return "eL numero"+ N1 + " es menor que " + N2;
 } else if (N1>N2){
     return "eL numero"+ N1 + " es mayor que " + N2;
 } else if (N1===N2){
    "eL numero"+ N1 + " es igual a " + N2;
 }

}

console.log (mayorMenorIgual(15,3));

//generaciones//

//BUCLES Y ARRAY //



let peliculas = ["star wars", "totoro",  "rocky", "pulp fiction",  "la vida es bella"]

function convertirAMayusculas(peliculas){
    let array1 = [];
    pasajeDeElementos(array1,peliculas);
    function pasajeDeElementos(array1, peliculas) {
        array1.push(peliculas.pop().toUpperCase())
        array1.push(peliculas.pop().toUpperCase())
        array1.push(peliculas.pop().toUpperCase())
        array1.push(peliculas.pop().toUpperCase())
        array1.push(peliculas.pop().toUpperCase())
        return array1
      }

      console.log(array1);
  }
convertirAMayusculas(peliculas);

let peliculas = ["star wars", "totoro",  "rocky", "pulp fiction",  "la vida es bella"]

function convertirAMayusculas(peliculas){
for(let i=0; i< peliculas.length; i++){
    let mayusc = peliculas[i];
    peliculas [i] = mayusc.toUpperCase();

}

return peliculas;
}
console.log(convertirAMayusculas(peliculas));


