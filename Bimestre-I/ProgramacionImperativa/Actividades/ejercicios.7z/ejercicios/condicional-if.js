let clima = 'Soleado';
let dia = 'Martes';

if( clima == 'Soleado' && dia == 'Domingo'){
    console.log ('bello dia para pasear');
}else if( clima == 'Soleado'&& dia == 'Lunes'){
    console.log ('puede salir igual')
}else{
    console.log ('mejor me quedo en casa si no es ni Domingo ni lunes ')
}

//ejercio de playground//
 let dato = "false";
 if(dato == "true"){
     console.log("es true");
 }else{
     console.log ("es false")
 }

//segundo de if-elseif-else

let lenguaje =".net";

if (lenguaje ==="javascript"){
    console.log ("Estoy aprendiendo");

}else{
    console.log ("Lo aprenderé más adelante");
}
// tercer ejercicio//



// segundo punto 

function puedePasar(nombre) {
    
        if (nombre == "Cosme Fulanito"){
            return false;
           
        }
        else{
            return true;

        }
}
         
       // if ternario/switch

       switch (expresion) {
           case caso1:
               console.log("se cumple caso1")
            break; // corta la ejecucion de codigo y sale del switch para evaluar sigueinte condicion

       }

        // segundo ejemplo 



        
    

        let dia = 'jueves'
        function finDeSemana (dia) {	
            if (dia == 'viernes') {
                console.log('buen finde')
            } else if (dia == 'lunes') {
                console.log('buena semana')
            } else {
                console.log('buen dia')
            }
        }