//A) Acceder a elementos especificos de un array.
let productos=["Arroz","Pan","Azucar","Carne"];
console.log("array original :["+productos[0],productos[1],productos[2],productos[3]+"]");

//B) Modificar cada uno de sus elementos e imprimirlos
productos[0]="Fideo";
productos[1]="Cafe";
productos[2]="Sal";
productos[3]="Pollo";
console.log("array modificado: ["+productos[0],productos[1],productos[2],productos[3]+"]");

//C) Agregar elementos a un array
//push -> elemento al final de la lista
productos.push("Lenteja","Jugo","Gaseosa");
console.log("array agregar producto al final: "+productos);

//unshift() agrega elementos al inicio de la lista  
productos.unshift("Harina");
console.log("array agregar producto al inicio: "+productos);

//D)Extraer elementos de un array
productos.pop();
console.log("array eliminamos producto: "+productos);