let day = 'Martes';
switch(day){            
case 'lunes':
console.log ('El lunes se trabaja');
 break;


case 'sabado':
    console.log ('patinaje thomi');
break;


case 'viernes':
    console.log ('Parcial' );
break;
case 'Domingo':
    console.log ('DESCANSO');
break;
default:
console.log("Estas libre si no es lunes,viernes,sabado o Domingo");
break;
}

// switchcase y funciones

let dia = 'lunes';
function finDeSemana(dia){

    switch(dia){            
        case 'lunes':
        console.log('buena semana ');
        break;
        case 'viernes':
        console.log ('buen finde');
        break;
        default:
        console.log ('buen dia');
 
    }

}
finDeSemana(dia);


//Tengo clase
let diadeclase = 'miércoles'

function tengoClases(diadeclase){
    switch(diadeclase){
        case "lunes":
        case "miércoles":
        case "viernes":
        console.log ("tenés clases")
        break;
        default:
        console.log ("no tenés clases")
    }
}
tengoClases(diadeclase);