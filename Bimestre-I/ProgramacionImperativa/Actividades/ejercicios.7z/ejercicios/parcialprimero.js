function esDivisible(num1, num2) {
    if(num1 % num2 === 0) {
        return `El numero ${num1} es divisible por ${num2}.`;
    } else {
            return `El numero ${num1} NO es divisible por ${num2}.`;}
}

    console.log(esDivisible(15,2));

    //segundo punto//

 

    
