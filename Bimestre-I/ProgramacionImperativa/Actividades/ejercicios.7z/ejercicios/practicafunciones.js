let nombre = "sandra";
let edad = 32;
let cumpleaños = 'Junio 01, 1988';
let ciudad = "Bogota";
let ocupacion = "Desarrolladora Web";
let hobbie = "Montar Bici";

nombre = "sandra milena sanchez parra";

console.log ("me llamo" +" " + nombre + " "+ "tengo en años " + edad + " " +"Mi fecha de cumple es" + " " + cumpleaños + " vivo en la hermosa " + ciudad+ " me costo pero soy "+ ocupacion +" Me encanta"+ hobbie+ "GRACIAS!! ");

nombre = "ANDO PROBANDO COSAS";

console.log(nombre);

//Repaso javascrip//

//condiciones//
 let condition =

 function sumarnumeros(n1,n2){

    return n1 + n2 ;
 }


