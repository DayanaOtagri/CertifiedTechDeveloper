let adivinaElnumero = function (num,nombre) {
    let numSecreto = 6;

    if (num > 10 || num < 1) {
    return "Por favor ingrese un numero entre 1 y 10";
    } else if (numSecreto === num) {
     return `¡¡ Felicidades ${nombre}, acertaste !! (numero ingresado: ${num});numero secreto: ${numSecreto}).`;
    } else {
      return " lo siento ${nombre}, el numero ingresado (${num}) no coincide con el numero secreto , intentalo nuevamente";
    } 
};
console.log (adivinaElnumero(6,"sandra"));

 