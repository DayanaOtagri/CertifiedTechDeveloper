const apiBaseUrl = 'https://pokeapi.co/api/v2/';
const pokemon = 'pokemon/';

function callApi(name) {
    fetch(apiBaseUrl + pokemon + name)
        .then(response => {
            return response.json();
        })
        .then(data => {
            let img = document.querySelector('img');
            img.setAttribute('src', data.sprites.front_default);

            let div = document.querySelector('div');
            div.classList.remove('skeleton');
        });
}


document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();

    let pokemonName = document.querySelector('input').value;
    callApi(pokemonName);
});