# Skeletons & Pokemons! <img src="https://image.flaticon.com/icons/png/512/287/287221.png" width='25px'>

Esta actividad, consiste en mejorar nuestra pokédex, agregando skeletons de carga mientras la página se encuentra esperando la información que proviene de la API.

Para ello, deberás manipular cada una de las cards creadas para mostrar un skeleton en su lugar, hasta tanto se complete la carga de la información. Una vez realizada esta tarea, deberás reemplazar los skeletons por las cards con la información de cad pokemon.

Una vez realizada la actividad, deberás ver el siguiente resultado final:

<img src="./assets/skeleton.gif" width='90%'>

Atrapalos ya! <img src='https://image.flaticon.com/icons/png/512/528/528098.png' width="25px"> <img src='https://image.flaticon.com/icons/png/512/189/189001.png' width="25px"><img src='https://image.flaticon.com/icons/png/512/188/188993.png' width="25px">
