package Pizzeria;

public class Simple extends Pizza{

    private double precioBase;
    private boolean grande;


    @Override
    public double calcularPrecio() {
        if (grande){
            return precioBase*2.0;
        }else {
            return precioBase;
        }
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }

    public boolean isGrande() {
        return grande;
    }

    public void setGrande(boolean grande) {
        this.grande = grande;
    }

    public void mostrarContenido(){
        System.out.println(toString());
    }

    @Override
    public String toString(){
        return "Nombre: "+getNombre()+" - Precio: "+calcularPrecio()+" pesos";
    }
}
