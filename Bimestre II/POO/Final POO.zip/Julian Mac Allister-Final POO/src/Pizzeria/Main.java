package Pizzeria;

public class Main {

    public static void main(String[] args) {

        Pizzeria p1=new Pizzeria();

        Pizza p2=PizzaFactory.getPizza().constructorPizza("Simple");
        p2.setNombre("Pizza de muzzarella chica");
        ((Simple)p2).setPrecioBase(700.0);
        ((Simple)p2).setGrande(false);

        Pizza p3=PizzaFactory.getPizza().constructorPizza("Simple");
        p3.setNombre("Media pizza especial ");
        ((Simple)p3).setPrecioBase(850.0);
        ((Simple)p3).setGrande(false);

        Pizza p4=PizzaFactory.getPizza().constructorPizza("Simple");
        p4.setNombre("Media pizza de ananá ");
        ((Simple)p4).setPrecioBase(950.0);
        ((Simple)p4).setGrande(false);

        Pizza p6=PizzaFactory.getPizza().constructorPizza("Simple");
        p6.setNombre("Pizza de ananá chica");
        ((Simple)p6).setPrecioBase(950.0);
        ((Simple)p6).setGrande(false);

        Pizza p7=PizzaFactory.getPizza().constructorPizza("Simple");
        p7.setNombre("Pizza especial chica");
        ((Simple)p7).setPrecioBase(850.0);
        ((Simple)p7).setGrande(false);

        Pizza p5=PizzaFactory.getPizza().constructorPizza("Combinada");
        p5.setNombre("Pizza combinada loca");
        ((Combinada)p5).addPizza(p3);
        ((Combinada)p5).addPizza(p4);

        p1.addPizza(p5);
        p1.addPizza(p6);
        p1.addPizza(p7);
        p1.addPizza(p2);

        p1.mostrarPizzas();


    }
}
