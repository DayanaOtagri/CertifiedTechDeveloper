package Pizzeria;

import java.util.ArrayList;
import java.util.List;

public class Pizzeria {

    private String nombre;
    private List<Pizza> pizzas1=new ArrayList<Pizza>();

    public void addPizza(Pizza pi){
        if (pi instanceof Simple || pi instanceof Combinada ) {
            pizzas1.add(pi);
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void mostrarPizzas(){
        for (Pizza pizza : pizzas1) {
            if(pizza instanceof Simple){
                ((Simple)pizza).mostrarContenido();
            }else if(pizza instanceof Combinada){
                ((Combinada)pizza).mostrarContenido();
            }
        }
    }


}
