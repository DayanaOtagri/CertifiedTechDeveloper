package Pizzeria;

import java.util.ArrayList;
import java.util.List;

public class Combinada extends Pizza{
    private List<Pizza> pizzas=new ArrayList<Pizza>();


    @Override
    public double calcularPrecio() {
        double total=0;
        for (Pizza pizza : pizzas) {
            total+=pizza.calcularPrecio();
        }
        return total/pizzas.size();
    }

    public void addPizza(Pizza pi){
        if (pi instanceof Simple ) {
            pizzas.add(pi);
        }
    }

    @Override
    public String toString(){
        return "Nombre: "+getNombre()+" -Precio: "+calcularPrecio();
    }

    public void mostrarContenido(){
        System.out.println(toString()+" contiene: " );
        for (Pizza pizza : pizzas) {
                ((Simple)pizza).mostrarContenido();
        }
        System.out.println("-------------------x--------------------");
    }
}
