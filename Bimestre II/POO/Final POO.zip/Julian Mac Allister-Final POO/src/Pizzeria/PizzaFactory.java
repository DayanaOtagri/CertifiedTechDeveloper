package Pizzeria;

public class PizzaFactory {

    private static PizzaFactory pizza;

    public static PizzaFactory getPizza(){
        if(pizza==null){
            pizza=new PizzaFactory();
        }
        return pizza;
    }

    public Pizza constructorPizza(String tipo){
        switch (tipo){
            case "Simple":
                return new Simple();
            case "Combinada":
                return new Combinada();
            default:
                return null;
        }
    }
}
